--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.14
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE dw_dvdrental;
--
-- Name: dw_dvdrental; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE dw_dvdrental WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE dw_dvdrental OWNER TO postgres;

\connect dw_dvdrental

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dw_customer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_customer (
    customer_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45) NOT NULL,
    email character varying(50),
    active integer,
    address character varying(50) NOT NULL,
    district character varying(20) NOT NULL,
    phone character varying(20) NOT NULL,
    city character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    last_update timestamp without time zone NOT NULL
);


ALTER TABLE public.dw_customer OWNER TO postgres;

--
-- Name: dw_customer_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_customer_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_customer_customer_id_seq OWNER TO postgres;

--
-- Name: dw_customer_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_customer_customer_id_seq OWNED BY public.dw_customer.customer_id;


--
-- Name: dw_date; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_date (
    date date NOT NULL,
    year integer,
    month character varying(20),
    day integer
);


ALTER TABLE public.dw_date OWNER TO postgres;

--
-- Name: dw_film; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_film (
    film_id integer NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    release_year integer,
    language character(20),
    rental_duration smallint,
    length smallint,
    last_update timestamp without time zone
);


ALTER TABLE public.dw_film OWNER TO postgres;

--
-- Name: dw_film_film_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_film_film_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_film_film_id_seq OWNER TO postgres;

--
-- Name: dw_film_film_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_film_film_id_seq OWNED BY public.dw_film.film_id;


--
-- Name: dw_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_sales (
    sales_id integer NOT NULL,
    store_fk integer NOT NULL,
    staff_fk integer NOT NULL,
    customer_fk integer NOT NULL,
    film_fk integer NOT NULL,
    date_fk date NOT NULL,
    amount numeric(5,2)
);


ALTER TABLE public.dw_sales OWNER TO postgres;

--
-- Name: dw_sales_customer_fk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_sales_customer_fk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_sales_customer_fk_seq OWNER TO postgres;

--
-- Name: dw_sales_customer_fk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_sales_customer_fk_seq OWNED BY public.dw_sales.customer_fk;


--
-- Name: dw_sales_film_fk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_sales_film_fk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_sales_film_fk_seq OWNER TO postgres;

--
-- Name: dw_sales_film_fk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_sales_film_fk_seq OWNED BY public.dw_sales.film_fk;


--
-- Name: dw_sales_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_sales_sales_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_sales_sales_id_seq OWNER TO postgres;

--
-- Name: dw_sales_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_sales_sales_id_seq OWNED BY public.dw_sales.sales_id;


--
-- Name: dw_sales_staff_fk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_sales_staff_fk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_sales_staff_fk_seq OWNER TO postgres;

--
-- Name: dw_sales_staff_fk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_sales_staff_fk_seq OWNED BY public.dw_sales.staff_fk;


--
-- Name: dw_sales_store_fk_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_sales_store_fk_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_sales_store_fk_seq OWNER TO postgres;

--
-- Name: dw_sales_store_fk_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_sales_store_fk_seq OWNED BY public.dw_sales.store_fk;


--
-- Name: dw_staff; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_staff (
    staff_id integer NOT NULL,
    first_name character varying(45) NOT NULL,
    last_name character varying(45) NOT NULL,
    email character varying(50),
    active boolean NOT NULL,
    username character varying(16) NOT NULL,
    password character varying(40),
    address character varying(50),
    district character varying(20),
    phone character varying(20),
    city character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    last_update timestamp without time zone
);


ALTER TABLE public.dw_staff OWNER TO postgres;

--
-- Name: dw_staff_staff_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_staff_staff_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_staff_staff_id_seq OWNER TO postgres;

--
-- Name: dw_staff_staff_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_staff_staff_id_seq OWNED BY public.dw_staff.staff_id;


--
-- Name: dw_store; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.dw_store (
    store_id integer NOT NULL,
    address character varying(50) NOT NULL,
    district character varying(20) NOT NULL,
    phone character varying(20) NOT NULL,
    city character varying(50) NOT NULL,
    country character varying(50) NOT NULL,
    last_update timestamp without time zone NOT NULL
);


ALTER TABLE public.dw_store OWNER TO postgres;

--
-- Name: dw_store_store_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.dw_store_store_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.dw_store_store_id_seq OWNER TO postgres;

--
-- Name: dw_store_store_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.dw_store_store_id_seq OWNED BY public.dw_store.store_id;


--
-- Name: dw_customer customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_customer ALTER COLUMN customer_id SET DEFAULT nextval('public.dw_customer_customer_id_seq'::regclass);


--
-- Name: dw_film film_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_film ALTER COLUMN film_id SET DEFAULT nextval('public.dw_film_film_id_seq'::regclass);


--
-- Name: dw_sales sales_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales ALTER COLUMN sales_id SET DEFAULT nextval('public.dw_sales_sales_id_seq'::regclass);


--
-- Name: dw_sales store_fk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales ALTER COLUMN store_fk SET DEFAULT nextval('public.dw_sales_store_fk_seq'::regclass);


--
-- Name: dw_sales staff_fk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales ALTER COLUMN staff_fk SET DEFAULT nextval('public.dw_sales_staff_fk_seq'::regclass);


--
-- Name: dw_sales customer_fk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales ALTER COLUMN customer_fk SET DEFAULT nextval('public.dw_sales_customer_fk_seq'::regclass);


--
-- Name: dw_sales film_fk; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales ALTER COLUMN film_fk SET DEFAULT nextval('public.dw_sales_film_fk_seq'::regclass);


--
-- Name: dw_staff staff_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_staff ALTER COLUMN staff_id SET DEFAULT nextval('public.dw_staff_staff_id_seq'::regclass);


--
-- Name: dw_store store_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_store ALTER COLUMN store_id SET DEFAULT nextval('public.dw_store_store_id_seq'::regclass);


--
-- Data for Name: dw_customer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_customer (customer_id, first_name, last_name, email, active, address, district, phone, city, country, last_update) FROM stdin;
\.
COPY public.dw_customer (customer_id, first_name, last_name, email, active, address, district, phone, city, country, last_update) FROM '$$PATH$$/3115.dat';

--
-- Data for Name: dw_date; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_date (date, year, month, day) FROM stdin;
\.
COPY public.dw_date (date, year, month, day) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: dw_film; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_film (film_id, title, description, release_year, language, rental_duration, length, last_update) FROM stdin;
\.
COPY public.dw_film (film_id, title, description, release_year, language, rental_duration, length, last_update) FROM '$$PATH$$/3119.dat';

--
-- Data for Name: dw_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_sales (sales_id, store_fk, staff_fk, customer_fk, film_fk, date_fk, amount) FROM stdin;
\.
COPY public.dw_sales (sales_id, store_fk, staff_fk, customer_fk, film_fk, date_fk, amount) FROM '$$PATH$$/3126.dat';

--
-- Data for Name: dw_staff; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_staff (staff_id, first_name, last_name, email, active, username, password, address, district, phone, city, country, last_update) FROM stdin;
\.
COPY public.dw_staff (staff_id, first_name, last_name, email, active, username, password, address, district, phone, city, country, last_update) FROM '$$PATH$$/3117.dat';

--
-- Data for Name: dw_store; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.dw_store (store_id, address, district, phone, city, country, last_update) FROM stdin;
\.
COPY public.dw_store (store_id, address, district, phone, city, country, last_update) FROM '$$PATH$$/3113.dat';

--
-- Name: dw_customer_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_customer_customer_id_seq', 1, false);


--
-- Name: dw_film_film_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_film_film_id_seq', 1, false);


--
-- Name: dw_sales_customer_fk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_sales_customer_fk_seq', 1, false);


--
-- Name: dw_sales_film_fk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_sales_film_fk_seq', 1, false);


--
-- Name: dw_sales_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_sales_sales_id_seq', 1, false);


--
-- Name: dw_sales_staff_fk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_sales_staff_fk_seq', 1, false);


--
-- Name: dw_sales_store_fk_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_sales_store_fk_seq', 1, false);


--
-- Name: dw_staff_staff_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_staff_staff_id_seq', 1, false);


--
-- Name: dw_store_store_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.dw_store_store_id_seq', 1, false);


--
-- Name: dw_customer dw_customer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_customer
    ADD CONSTRAINT dw_customer_pkey PRIMARY KEY (customer_id);


--
-- Name: dw_date dw_date_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_date
    ADD CONSTRAINT dw_date_pkey PRIMARY KEY (date);


--
-- Name: dw_film dw_film_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_film
    ADD CONSTRAINT dw_film_pkey PRIMARY KEY (film_id);


--
-- Name: dw_sales dw_sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_pkey PRIMARY KEY (sales_id);


--
-- Name: dw_staff dw_staff_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_staff
    ADD CONSTRAINT dw_staff_pkey PRIMARY KEY (staff_id);


--
-- Name: dw_store dw_store_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_store
    ADD CONSTRAINT dw_store_pkey PRIMARY KEY (store_id);


--
-- Name: dw_sales dw_sales_customer_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_customer_fk_fkey FOREIGN KEY (customer_fk) REFERENCES public.dw_customer(customer_id);


--
-- Name: dw_sales dw_sales_date_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_date_fk_fkey FOREIGN KEY (date_fk) REFERENCES public.dw_date(date);


--
-- Name: dw_sales dw_sales_film_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_film_fk_fkey FOREIGN KEY (film_fk) REFERENCES public.dw_film(film_id);


--
-- Name: dw_sales dw_sales_staff_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_staff_fk_fkey FOREIGN KEY (staff_fk) REFERENCES public.dw_staff(staff_id);


--
-- Name: dw_sales dw_sales_store_fk_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.dw_sales
    ADD CONSTRAINT dw_sales_store_fk_fkey FOREIGN KEY (store_fk) REFERENCES public.dw_store(store_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

